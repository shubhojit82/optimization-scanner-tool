# GEO Workbench architecture — foundation v0.1

This is the first working slice, not a production enterprise platform. It establishes evidence contracts, dependency boundaries, persistent client records, cue scoring, prompt generation and manual observations. Automated crawl, provider sampling, organization roles and CMS publishing are later slices.

## Dependency rule

UI → HTTP adapter → application services → domain contracts and rules.
Infrastructure adapters implement domain ports. The domain imports no React, Cloudflare, ORM, provider SDK or CMS package. The composition root is `src/adapters/http.ts`. The current runtime is React/Vinext + a Cloudflare Worker + D1; domain and application modules can move to Node without changing their behavior.

| Module | Responsibility | Replaceable implementation |
| --- | --- | --- |
| `src/core/contracts.ts` | Canonical Client, Audit, Observation; repository, crawler, provider, CMS and queue ports | TypeScript contracts today; language-neutral HTTP/event schemas for future cross-language services |
| `src/core/scoring.ts` | Versioned cue rubric, prompt templates, observed mention/citation calculations | Rules can evolve under new versions without modifying historical results |
| `src/application/workbench.ts` | Owner access checks, audit orchestration, observation import | Runtime-independent application service |
| `src/adapters/d1-repository.ts` | Prepared SQL, persistent storage and bounded reads | PostgreSQL, another database or a service implementing Repository |
| `src/adapters/http.ts` | Validation, bounded request bodies, identity, origin checks, composition | HTTP framework and hosting identity adapter |
| `app/workbench-ui.tsx` | Client workspace | Any UI consuming the versioned API |

The existing Crawler, AIProvider, CMSConnector and JobQueue interfaces are extension seams, not connected services. Any CMS can integrate if an adapter maps its content, identity, versions and permissions into these contracts. Changing language or hosting still requires adapter work; plug compatibility is not automatic.

## Storage and security boundary

New deployment is owner-private. Platform sign-in supplies a trusted user identifier; the host must strip spoofed identity headers before forwarding requests. The worker is not intended to be exposed directly on an untrusted ingress. Each client and record query includes `owner`; application services verify client ownership before reading or writing child records. Writes require a same-origin Origin header. SQL values are bound, request bodies are limited to 600 KB, HTML is limited to 250,000 characters, and manual imports to 20 observations per batch.

This is **user isolation**, not full enterprise multitenancy. For organization teams, add workspace, membership, role and resource policy tables; resolve tenant membership on every request and worker job. Never accept a browser-supplied tenant as authorization. Add database constraints or PostgreSQL row-level policies as defense in depth, and transactional outbox records for queued work.

Clients and audit/observation envelopes are stored in indexed tables. JSON envelopes simplify the first slice; replace them with indexed normalized page/run/query/observation tables when reporting requires joins. Current list limits: 100 clients, latest 200 audits and latest 200 observations per client. Pagination, deduplication, retention and deletion are not yet implemented.

Imported HTML is analyzed as inert text and discarded after analysis. Immutable audit records retain dimensions, evidence explanations, URL, source, timestamp, SHA-256 input hash and rubric version. The hash proves input equality, not authenticity or recoverability. Raw evidence retention should later use object storage with tenant keys, encryption, retention and provenance. Do not send imported client content to a model until the provider and data handling are configured.

## Scoring and measurement

The nine rubric weights total 100. HTML imports assess five dimensions totaling 70: page structure (10), brand clarity (15), answer structure (20), reference cues (15), structured data cues (10). Crawler access (15), freshness (5), external authority (5) and monitoring coverage (5) remain unknown.

`assessed score = round(sum(weight × cue score) / sum(assessed weights))`

Unknowns are excluded and coverage is shown beside the score. This is a proprietary heuristic for implementation review, not a validated predictor of search ranking. A single external link satisfies a reference *cue*; it does not establish source quality. JSON-LD checks syntax and presence of a typed node; it does not validate schema semantics. The 150-word signal is a provisional rubric cue, not a search-engine requirement or recommendation to add filler. Regex-based extraction handles conventional quoted attributes, not arbitrary malformed HTML, DOM execution, CSS visibility or entity normalization. Improve parser coverage and calibrate the rubric against reviewed examples before commercial use.

Google's official guidance says foundational SEO and useful original content matter, with no special structured data requirement for generative search. Do not market structured data as a guaranteed GEO boost. OpenAI distinguishes search discovery controls from training crawler controls; the next crawler must assess them separately.

Mention rate is the percentage of imported response strings with a case-insensitive brand match using Unicode letter/number boundaries. Citation rate is the percentage with at least one supplied citation URL on the client domain/subdomain. Both denominators use up to the 200 latest imported rows, across all engines/surfaces. The app retains model, surface, prompt and observed timestamp. Rates describe that sample; they are not population estimates, consumer UI rankings, causal impact or recommendations. Manual citations and responses are user-supplied and not independently verified. Duplicate imports count twice. No GSOV, sentiment, inferred recommendation, projections or competitive rank is fabricated.

## Scaling sequence and acceptance gates

1. **Foundation (implemented):** immutable audit snapshots, bounded APIs, user isolation, cue scoring, query templates and manual observations. Domain tests and TypeScript build pass.
2. **Automated collection:** add queued HTTP crawler and rendered-page worker. Parse robots policies correctly, respect per-domain concurrency/rate budgets, bound redirects/bytes/time, reject private/link-local/loopback addresses at DNS and connection time, pin verified destination addresses, and defend against DNS rebinding. Capture headers, sitemap, robots, canonical and rendering evidence. Worker HTTP responses return a job ID; they do not run long crawls inline. Gate: reproducible snapshot on a real authorized site; cancellation, retries and SSRF tests.
3. **Provider measurement:** add one official API adapter with server-side secrets, quotas and a per-tenant cost ceiling. Specify surface, model, locale, timestamp, search settings and sampling repetitions. Separate API-grounded measurements from consumer products. Jobs need idempotency keys, retry classification, exponential backoff, dead-letter handling and immutable run/query versions. Gate: repeated observations with source evidence; provider failures never count as zero visibility.
4. **Enterprise and remediation:** memberships/RBAC, audit logs, approvals, draft diff/version preconditions and CMS adapters. Start with AEM or Contentstack based on the first client. Gate: read and draft staging without unintended publishing; authorization and version-conflict tests.
5. **Scale by measured bottleneck:** move capture/evaluation to separate worker services first. Replace storage adapter with PostgreSQL and object storage; introduce materialized analytics and partition retention as measured workloads demand. Use OpenAPI for synchronous contracts and a versioned event envelope (`id`, `tenantId`, `type`, `version`, `payload`, later trace/causation IDs). Move secrets, migrations, observability and identity integration explicitly; the core itself stays stable.

No premature microservices or Kubernetes dependency is introduced. Deployment portability comes from clear adapters, not from assuming every vendor is interchangeable. Add contract fixtures for every new adapter and verify it against the same application service tests.

## Next concrete build

Implement an asynchronous crawler worker and CrawlRepository/JobQueue adapter, with a safe egress policy and a 20-page baseline per authorized client. Then integrate one AI search provider and a stable prompt-run model. These are separate increments with measurable acceptance gates.

## Sources verified October 5, 2026

- https://developers.google.com/search/docs/fundamentals/ai-optimization-guide
- https://developers.openai.com/api/docs/bots
