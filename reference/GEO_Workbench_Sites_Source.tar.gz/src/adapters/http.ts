import { z } from 'zod';
import { D1Repository } from './d1-repository';
import { Workbench } from '../application/workbench';
export const repo = new D1Repository();
export const workbench = new Workbench(repo);
export const urlSchema = z.string().url().max(2048).refine(s => { const u = new URL(s); return ['https:', 'http:'].includes(u.protocol) && !u.username && !u.password; }, 'Use an HTTP(S) URL without credentials');
export const clientSchema = z.object({ name: z.string().trim().min(2).max(100), domain: urlSchema, industry: z.string().trim().min(2).max(120), market: z.string().trim().min(2).max(100), products: z.array(z.string().trim().min(1).max(120)).max(10), competitors: z.array(z.string().trim().min(1).max(100)).max(5) }).strict();
export const auditSchema = z.object({ url: urlSchema, html: z.string().min(20).max(250000) }).strict();
export const observationSchema = z.array(z.object({ engine: z.string().trim().min(1).max(60), surface: z.string().trim().min(1).max(100), model: z.string().trim().min(1).max(100), prompt: z.string().trim().min(5).max(2000), response: z.string().trim().min(1).max(12000), citations: z.array(urlSchema).max(30), observedAt: z.string().datetime().refine(s => new Date(s).getTime() <= Date.now(), 'Observation date cannot be in the future') }).strict()).min(1).max(20);
export function identity(r: Request) { const id = r.headers.get('oai-authenticated-user-id'); if (!id)
    throw new Error('Sign in required'); if (r.method !== 'GET') {
    const origin = r.headers.get('origin');
    if (!origin || origin !== new URL(r.url).origin)
        throw new Error('Origin denied');
} return id; }
export async function body(r: Request) { const reader = r.body?.getReader(); if (!reader)
    throw new Error('Request body required'); let size = 0; const chunks: Uint8Array[] = []; while (true) {
    const v = await reader.read();
    if (v.done)
        break;
    size += v.value.length;
    if (size > 600000) {
        await reader.cancel();
        throw new Error('Request too large');
    }
    chunks.push(v.value);
} const joined = new Uint8Array(size); let at = 0; for (const c of chunks) {
    joined.set(c, at);
    at += c.length;
} return JSON.parse(new TextDecoder().decode(joined)); }
export async function endpoint(fn: () => Promise<unknown>) { try {
    return Response.json(await fn(), { headers: { 'Cache-Control': 'no-store' } });
}
catch (e) {
    const message = e instanceof z.ZodError ? e.issues[0]?.message : e instanceof SyntaxError ? 'Invalid JSON' : e instanceof Error ? e.message : 'Request failed';
    const status = message === 'Sign in required' ? 401 : message === 'Origin denied' ? 403 : message === 'Client not found' ? 404 : e instanceof z.ZodError || e instanceof SyntaxError || ['Page URL must belong to the client domain', 'Request too large', 'Request body required'].includes(message) ? 400 : 503;
    if (status === 503)
        console.error('Workbench request failed', e);
    return Response.json({ error: status === 503 ? 'Storage is temporarily unavailable. Please retry.' : message }, { status });
} }
