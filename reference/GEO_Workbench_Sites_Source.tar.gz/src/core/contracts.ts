export type Client = {
    id: string;
    name: string;
    domain: string;
    industry: string;
    products: string[];
    competitors: string[];
    market: string;
    created: string;
};
export type Dimension = {
    id: string;
    name: string;
    weight: number;
    score: number | null;
    evidence: string;
    action: string;
};
export type Audit = {
    id: string;
    clientId: string;
    url: string;
    created: string;
    version: string;
    source: 'html-import';
    hash: string;
    score: number;
    coverage: number;
    dimensions: Dimension[];
};
export type Observation = {
    id: string;
    clientId: string;
    engine: string;
    surface: string;
    model: string;
    prompt: string;
    response: string;
    citations: string[];
    observedAt: string;
    created: string;
    source: 'manual-import';
};
export interface Repository {
    listClients(owner: string): Promise<Client[]>;
    getClient(owner: string, id: string): Promise<Client | null>;
    saveClient(owner: string, client: Client): Promise<void>;
    listRecords<T>(owner: string, clientId: string, kind: 'audit' | 'observation'): Promise<T[]>;
    saveRecords(owner: string, clientId: string, kind: 'audit' | 'observation', records: {
        id: string;
        created: string;
    }[]): Promise<void>;
}
export type PageSnapshot = {
    url: string;
    html: string;
    fetchedAt: string;
    status: number;
    headers: Record<string, string>;
};
export interface Crawler {
    capture(url: string): Promise<PageSnapshot>;
}
export interface AIProvider {
    readonly id: string;
    observe(prompt: string, market: string): Promise<Omit<Observation, 'id' | 'clientId' | 'created' | 'source'>>;
}
export interface CMSConnector {
    readonly id: string;
    readPage(id: string): Promise<PageSnapshot & {
        version: string;
    }>;
    stageDraft(pageId: string, html: string, expectedVersion: string): Promise<{
        draftId: string;
    }>;
}
export interface JobQueue {
    enqueue(job: {
        id: string;
        tenantId: string;
        type: string;
        version: 1;
        payload: unknown;
    }): Promise<void>;
}
