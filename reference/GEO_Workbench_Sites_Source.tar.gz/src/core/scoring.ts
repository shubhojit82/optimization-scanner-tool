import type { Client, Dimension, Observation } from './contracts';
export const RUBRIC_VERSION = 'readiness-cues/1.0.0';
export function aggregate(dimensions: Dimension[]) { const known = dimensions.filter(d => d.score !== null); const coverage = known.reduce((n, d) => n + d.weight, 0); return { score: coverage ? Math.round(known.reduce((n, d) => n + d.weight * d.score!, 0) / coverage) : 0, coverage }; }
export function analyzeHtml(html: string, c: Client): Dimension[] {
    const clean = html.replace(/<!--[\s\S]*?-->/g, '');
    const visible = clean.replace(/<(script|style|nav|footer)\b[^>]*>[\s\S]*?<\/\1>/gi, '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    const tags = Array.from(clean.matchAll(/<(meta|link)\b([^>]*)>/gi), m => ({ tag: m[1].toLowerCase(), attrs: Object.fromEntries(Array.from(m[2].matchAll(/([\w-]+)\s*=\s*["']([^"']*)["']/g), a => [a[1].toLowerCase(), a[2]])) }));
    const title = /<title\b[^>]*>\s*\S[\s\S]*?<\/title>/i.test(clean), h1 = /<h1\b[^>]*>\s*\S[\s\S]*?<\/h1>/i.test(clean);
    const desc = tags.some(t => t.attrs.name?.toLowerCase() === 'description' && t.attrs.content?.trim());
    const canonical = tags.some(t => t.tag === 'link' && t.attrs.rel?.toLowerCase().split(/\s+/).includes('canonical') && t.attrs.href);
    const noindex = tags.some(t => t.attrs.name?.toLowerCase() === 'robots' && /\bnoindex\b/i.test(t.attrs.content || ''));
    let valid = 0, invalid = 0;
    for (const m of clean.matchAll(/<script\b[^>]*type\s*=\s*["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
        try {
            const j = JSON.parse(m[1]);
            const nodes = Array.isArray(j) ? j : [j, ...(Array.isArray(j?.['@graph']) ? j['@graph'] : [])];
            if (nodes.some(n => n && typeof n === 'object' && n['@type']))
                valid++;
            else
                invalid++;
        }
        catch {
            invalid++;
        }
    }
    const external = Array.from(clean.matchAll(/<a\b[^>]*href\s*=\s*["'](https?:\/\/[^"']+)["']/gi), m => m[1]).filter(s => { try {
        return new URL(s).hostname !== new URL(c.domain).hostname;
    }
    catch {
        return false;
    } }).length;
    const words = visible.split(/\s+/).filter(Boolean).length;
    const d = (id: string, name: string, weight: number, score: number | null, evidence: string, action: string): Dimension => ({ id, name, weight, score, evidence, action });
    return [
        d('crawl', 'Crawler access', 15, null, 'Imported HTML cannot establish robots rules, WAF access, or indexing.', 'Capture robots.txt, response headers, and crawler access evidence.'),
        d('technical', 'Page structure', 10, noindex ? 0 : 25 * [title, h1, desc, canonical].filter(Boolean).length, `Title ${title ? 'present' : 'missing'}; H1 ${h1 ? 'present' : 'missing'}; description ${desc ? 'present' : 'missing'}; canonical ${canonical ? 'present' : 'missing'}; noindex ${noindex ? 'detected' : 'not detected in HTML'}.`, 'Review title, H1, description, canonical and intended indexing policy.'),
        d('entity', 'Brand clarity', 15, visible.toLowerCase().includes(c.name.toLowerCase()) ? 100 : 0, `Brand name ${visible.toLowerCase().includes(c.name.toLowerCase()) ? 'found' : 'not found'} in extracted text. This does not validate entity authority.`, 'Identify the brand and explain its products in visible content.'),
        d('content', 'Answer structure', 20, 25 * [h1, /<h2\b/i.test(clean), words >= 150, /<(ul|ol|table)\b/i.test(clean)].filter(Boolean).length, `${words} extracted words; heading and list/table cues assessed. Answer accuracy and usefulness need human review.`, 'Use descriptive headings and clear, factual answers; add lists or tables where useful.'),
        d('evidence', 'Reference cues', 15, external ? 100 : 0, `${external} external reference link(s). Sources and claims have not been verified.`, 'Support material claims with relevant, verifiable references.'),
        d('schema', 'Structured data cues', 10, invalid ? 0 : valid ? 100 : 0, `${valid} typed JSON-LD block(s); ${invalid} invalid or untyped block(s). Syntax cues only; no semantic validation.`, 'Consider relevant structured data matching visible content. It is not required for AI visibility.'),
        d('freshness', 'Content freshness', 5, null, 'Publication dates alone cannot verify freshness.', 'Review factual currency against a dated source of truth.'),
        d('authority', 'External authority', 5, null, 'Third-party reputation has not been assessed.', 'Collect independent references and validate their relevance.'),
        d('measurement', 'Monitoring coverage', 5, null, 'This page import does not establish a monitored prompt set.', 'Establish a repeatable prompt set and dated engine observations.')
    ];
}
export function queryUniverse(c: Client) { return (c.products.length ? c.products : [c.industry]).flatMap(p => [{ intent: 'Education', prompt: `What is ${p} and who is it for?` }, { intent: 'Evaluation', prompt: `Which ${p} providers should a business in ${c.market} evaluate?` }, { intent: 'Implementation', prompt: `How can a business implement ${p}?` }, ...c.competitors.map(k => ({ intent: 'Comparison', prompt: `How does ${c.name} compare with ${k} for ${p}?` }))]); }
export function visibility(c: Client, rows: Observation[]) { const hostname = new URL(c.domain).hostname.replace(/^www\./, ''); const escaped = c.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); const name = new RegExp(`(^|[^\\p{L}\\p{N}])${escaped}($|[^\\p{L}\\p{N}])`, 'iu'); const mentions = rows.filter(r => name.test(r.response)).length; const citations = rows.filter(r => r.citations.some(u => { const h = new URL(u).hostname.replace(/^www\./, ''); return h === hostname || h.endsWith('.' + hostname); })).length; return { sample: rows.length, mentionRate: rows.length ? Math.round(mentions / rows.length * 100) : null, citationRate: rows.length ? Math.round(citations / rows.length * 100) : null }; }
